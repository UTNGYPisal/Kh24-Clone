package com.learn.android.khmer24clone.ui.auth

import androidx.lifecycle.liveData
import com.learn.android.khmer24clone.model.api.UnhandledResult
import com.learn.android.khmer24clone.model.repo.AuthRepo
import com.learn.android.khmer24clone.ui.base.BaseViewModel

class LoginViewModel : BaseViewModel(){


}