package com.learn.android.khmer24clone.ui.chat

import com.learn.android.khmer24clone.R
import com.learn.android.khmer24clone.ui.base.BaseFragment

class ChatFragment : BaseFragment(R.layout.fragment_chat){

}