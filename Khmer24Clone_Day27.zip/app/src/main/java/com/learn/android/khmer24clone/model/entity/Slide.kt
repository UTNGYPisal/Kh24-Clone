package com.learn.android.khmer24clone.model.entity

data class Slide(
    val id: Int? = null,
    val url: String? = null,
    val name: String? = null
)