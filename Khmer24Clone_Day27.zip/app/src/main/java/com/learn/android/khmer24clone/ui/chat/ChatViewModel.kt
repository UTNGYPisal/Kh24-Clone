package com.learn.android.khmer24clone.ui.chat

import com.learn.android.khmer24clone.ui.base.BaseViewModel

class ChatViewModel: BaseViewModel(){

}