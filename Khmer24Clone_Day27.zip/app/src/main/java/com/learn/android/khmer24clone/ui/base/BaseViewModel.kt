package com.learn.android.khmer24clone.ui.base

import androidx.lifecycle.ViewModel

open class BaseViewModel : ViewModel(){

}