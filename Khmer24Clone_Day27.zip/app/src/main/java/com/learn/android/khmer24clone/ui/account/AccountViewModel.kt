package com.learn.android.khmer24clone.ui.account
import com.learn.android.khmer24clone.ui.base.BaseViewModel

class AccountViewModel : BaseViewModel() {

}