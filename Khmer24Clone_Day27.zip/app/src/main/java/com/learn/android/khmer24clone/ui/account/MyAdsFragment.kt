package com.learn.android.khmer24clone.ui.account

import com.learn.android.khmer24clone.R
import com.learn.android.khmer24clone.ui.base.BaseFragment

class MyAdsFragment : BaseFragment(R.layout.fragment_ads_list){

}