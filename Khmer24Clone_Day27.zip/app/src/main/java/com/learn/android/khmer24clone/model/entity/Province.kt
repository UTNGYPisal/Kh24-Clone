package com.learn.android.khmer24clone.model.entity

data class Province(
    val id: Int? = null,
    val name: String? = null
)