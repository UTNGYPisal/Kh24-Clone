package com.learn.android.khmer24clone.model.entity

data class ProductSpec(
    val key: String? = null,
    val value: String? = null
)