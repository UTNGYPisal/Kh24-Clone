package com.learn.android.khmer24clone.custom.helper

typealias ItemClickListener = (position: Int, data: Any?) -> Unit
typealias Completion = (success: Boolean, result: Any?, message: String?) -> Unit
